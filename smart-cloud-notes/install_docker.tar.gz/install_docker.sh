#!/bin/bash
yum -y install wget
cp /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bak
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
wget -P /etc/yum.repos.d/ http://mirrors.aliyun.com/repo/epel-7.repo
yum clean all
yum makecache
yum -y update
curl -fsSL get.docker.com -o get-docker.sh
sh get-docker.sh --mirror AzureChinaCloud
tee -a /etc/sysctl.conf <<-EOF
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF
mkdir -p /etc/docker
cd /etc/docker/
touch daemon.json
tee /etc/docker/daemon.json <<-EOF
{
	"registry-mirrors": ["https://registry.docker-cn.com"]
}
EOF
sysctl -p
systemctl enable docker
systemctl start docker
curl -L https://github.com/docker/compose/releases/download/1.24.0/docker-compose-`uname -s`-`uname -m` -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
